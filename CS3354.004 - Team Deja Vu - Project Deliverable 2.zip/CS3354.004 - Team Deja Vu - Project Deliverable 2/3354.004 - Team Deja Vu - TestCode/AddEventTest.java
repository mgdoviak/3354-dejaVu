import static org.junit.Assert.*;

import java.util.Calendar;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class AddEventTest {
	@BeforeClass
	public static void beforeClass() {
		System.out.println("Before class");
	}
	
	@Before
	public void before() {
		System.out.println("Before Test Case");
	}
	
	@Test
	public void test() {
		System.out.println("Test");
		AddEvent addEvent = new AddEvent();
		
		// Create calendar objects that represent the start and end times of the events
		Calendar start = Calendar.getInstance();
		Calendar end = Calendar.getInstance();
		
		// Set the end time to be after the start time
		start.set(Calendar.HOUR, start.get(Calendar.HOUR) + 1);
		end.set(Calendar.HOUR, end.get(Calendar.HOUR) + 2);
		assertTrue("Testing the end time being later than the start time", addEvent.isStartAndEndTimeValid(start, end));
	}
	
	@Test
	public void test2() {
		System.out.println("Test 2");
		AddEvent addEvent = new AddEvent();
		
		// Create calendar objects that represent the start and end times of the events
		Calendar start = Calendar.getInstance();
		Calendar end = Calendar.getInstance();
		
		// Set the end time to be before the start time
		start.set(Calendar.HOUR, start.get(Calendar.HOUR) + 2);
		end.set(Calendar.HOUR, end.get(Calendar.HOUR) + 1);
		
		assertFalse("Testing the end time being earlier than the start time", addEvent.isStartAndEndTimeValid(start, end));
	}
	
	@Test
	public void test3() {
		System.out.println("Test 3");
		AddEvent addEvent = new AddEvent();
		
		// Create calendar objects that represent the start and end times of the events
		Calendar start = Calendar.getInstance();
		Calendar end = (Calendar) start.clone(); // Set them equal to each other
		
		assertFalse("Testing the end and start times being the same", addEvent.isStartAndEndTimeValid(start, end));
	}
	
	@Test
	public void test4() {
		System.out.println("Test 4");
		AddEvent addEvent = new AddEvent();
		
		// Create calendar objects that represent the start and end times of the events
		Calendar start = Calendar.getInstance();
		Calendar end = Calendar.getInstance();
		
		// Set the start date to before the current date
		start.set(Calendar.HOUR, start.get(Calendar.HOUR) - 1);
		assertFalse("Testing start time being before the current time", addEvent.isStartAndEndTimeValid(start, end));
	}
	
	@After
	public void after() {
		System.out.println("After Test Case");
	}
	
	@AfterClass
	public static void afterClass() {
		System.out.println("After class");
	}
}
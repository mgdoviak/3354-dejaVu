import java.util.Calendar;

public class AddEvent {
	// Returns whether the given start and end times for an event are valid
	boolean isStartAndEndTimeValid(Calendar start, Calendar end) {
		// Check that the start time of the event is before the end time and that it starts after right now
		Calendar now = Calendar.getInstance();
		if (start.compareTo(end) < 0 && now.compareTo(start) < 0) {
			return true;
		}
		
		return false;
	}
}